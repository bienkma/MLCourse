package ai.vitk.reuters

import java.io.{File, InputStream, PrintWriter}

import net.liftweb.json._

import scala.collection.mutable.ListBuffer
import scala.io.Source

/**
  * phuonglh, 10/1/17, 21:47
  */
object IO {
  implicit val formats = DefaultFormats

  /**
    * Converts an SGML file to a JSON file.
    * @param sgmlPath
    * @param jsonPath
    */
  def sgml2json(sgmlPath: String, jsonPath: String): Unit = {
    val lines = Source.fromFile(sgmlPath, "UTF-8").getLines().filter(e => e.trim.nonEmpty && !e.contains("DOCTYPE")).toList
    val content = lines.map(line => line.replaceAll("\\&\\#[\\da-fA-F]+?\\;", "")).mkString("\n")
    val contentWithRoot = new StringBuilder()
    contentWithRoot.append("<root>")
    contentWithRoot.append(content)
    contentWithRoot.append("</root>")
    val xml: scala.xml.Elem = scala.xml.XML.loadString(contentWithRoot.toString())
    val documents = xml \ "REUTERS"
    val articles = documents.map(document => {
      val date = (document \ "DATE").text.trim
      val title = (document \ "TEXT" \ "TITLE").text.trim
      val body = (document \ "TEXT" \ "BODY").text.trim.replaceAll("\\s+", " ")
      Article(date, title, body)
    })
    println(articles.size)
    val json = net.liftweb.json.Serialization.write(articles)
    val file = new File(jsonPath)
    val writer = new PrintWriter(file, "UTF-8")
    writer.write(json)
    writer.close()    
  }

  /**
    * Reads a corpus of articles in a JSON file from
    * a resource path.
    * @param resourcePath a resource path
    * @return a list of [[Article]]
    */
  def readJson(resourcePath: String): List[Article] = {
    readJson(getClass.getResourceAsStream(resourcePath))
  }

  /**
    * Reads a corpus of articles in a JSON input stream.
    * @param inputStream an input stream
    * @return a list of [[Article]]
    */
  def readJson(inputStream: InputStream): List[Article] = {
    val lines = Source.fromInputStream(inputStream).getLines()
    val content = lines.mkString("\n")
    val json = parse(content)
    val data = new ListBuffer[Article]
    for (element <- json.children) {
      data += element.extract[Article]
    }
    data.toList.filter(e => e.title.trim.nonEmpty && e.body.trim.nonEmpty)
  }
  
  def main(args: Array[String]): Unit = {
//    sgml2json("dat/reuters21578/reut2-000.sgm", "dat/000.json")
    val articles = readJson("/000.json")
    articles.foreach(a => println(a.body))
    println("#(articles) = " + articles.size)
  }
}
