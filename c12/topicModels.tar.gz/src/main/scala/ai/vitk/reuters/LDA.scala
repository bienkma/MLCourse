package ai.vitk.reuters

import org.apache.spark.ml.{Pipeline, PipelineModel}
import org.apache.spark.ml.feature.{CountVectorizer, CountVectorizerModel, StopWordsRemover}
import org.apache.spark.sql.{Dataset, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.log4j.{Level, Logger}
import org.apache.spark.ml.clustering.LDAModel

/**
  * Implementation of a Latent Dirichlet Allocation model on the Reuters corpus.
  * phuonglh, phuonglh@gmail.com
  */
class LDA(val sparkSession: SparkSession) {

  final val logger = LoggerFactory.getLogger(getClass.getName)

  /**
    * Reads a list of articles from a JSON file and converts its to a [[Dataset]].
    * @param options
    * @return a dataset
    */
  def createDataset(options: Options): Dataset[Article] = {
    import sparkSession.implicits._
    val articles = IO.readJson(options.json())
    sparkSession.createDataset(articles).as[Article]
  }

  /**
    * Creates a processing pipeline.
    * @param options
    * @return a [[Pipeline]]
  */
  def createPipeline(options: Options): Pipeline = {
    val tokenizer = new Tokenizer().setInputCol("body").setOutputCol("tokens")
    StopWordsRemover.loadDefaultStopWords("english")
    val stopWordsRemover = new StopWordsRemover().setInputCol("tokens").setOutputCol("words")
    val wordCounter = new CountVectorizer().setInputCol("words").setOutputCol("features").setMinDF(options.frequency())
    val lda = new org.apache.spark.ml.clustering.LDA().setK(options.k()).setMaxIter(options.iteration())
    new Pipeline().setStages(Array(tokenizer, stopWordsRemover, wordCounter, lda))
  }

  /**
    * Trains a pipeline and saves the pipeline model to an external path.
    * @param options
    * @return a pipeline model.
    */
  def train(options: Options): PipelineModel = {
    val input = createDataset(options)
    input.show(20, false)
    val pipeline = createPipeline(options)
    logger.info("Training process started. Please wait...")
    val model = pipeline.fit(input)
    logger.info("Number of documents = " + input.count())
    val vocabulary = model.stages(2).asInstanceOf[CountVectorizerModel].vocabulary
    logger.info("Vocabulary size = " + vocabulary.size)
    val output = model.transform(input)
    output.select("words", "topicDistribution").show(10, false)
    val lda = model.stages(model.stages.size - 1).asInstanceOf[LDAModel]
    val ll = lda.logLikelihood(output)
    logger.info("The lower bound on the log likelihood of the corpus: " + ll)
    val topics = lda.describeTopics(options.top())
    logger.info("The topics described by their top-weighted terms: ")
    topics.show(options.k(), false)
    val termIndexToString = new TermIndexToString(vocabulary).setInputCol("termIndices").setOutputCol("terms")
    termIndexToString.transform(topics).select("topic", "terms").show(options.k(), false)
    model.write.overwrite().save(options.path())
    model
  }
}

object LDA {
  def main(args: Array[String]): Unit = {
    Logger.getLogger("org.apache.spark").setLevel(Level.ERROR)
    val sparkSession = SparkSession.builder().appName(getClass.getName)
      .master("local[*]")
      .config("spark.driver.host", "localhost")
      .config("spark.executor.memory", "8g")
      .getOrCreate()
    val lda = new LDA(sparkSession)
    val options = new Options(args)
    options.mode() match {
      case "train" => lda.train(options)
      case "eval" => {
      }
    }
    sparkSession.stop()
  }
}
