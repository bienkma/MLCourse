package ai.vitk.reuters

/**
  * phuonglh, 10/1/17, 21:49
  */
case class Article(date: String, title: String, body: String)
