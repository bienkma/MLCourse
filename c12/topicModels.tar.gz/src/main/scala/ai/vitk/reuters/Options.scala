package ai.vitk.reuters

import org.rogach.scallop.{ScallopConf}

/**
  * Created by phuonglh on 6/30/17.
  */
class Options(arguments: Seq[String]) extends ScallopConf(arguments) {
  val master = opt[String](default = Some("local[*]"), descr = "master URL to the cluster")
  val memory = opt[String](default = Some("8g"), descr = "executor memory")
  val mode = opt[String](default = Some("eval"), descr = "evaluate the accuracy of the classifier")
  val verbose = opt[Boolean](default = Some(false), descr = "verbose mode")
  val language = opt[String](default = Some("eng"), descr = "natural language in use")
  val frequency = opt[Int](default = Some(5), descr = "min feature frequency")
  val dimension = opt[Int](default = Some(1024), descr = "domain dimension for feature hashing")
  val iteration = opt[Int](default = Some(100), descr = "max number of iterations in training")
  val k = opt[Int](default = Some(20), descr = "number of topics")
  val top = opt[Int](default = Some(10), descr = "top words in each topic")
  val hadoop = opt[Boolean](default = Some(false), descr = "use HDFS file system instead of a local directory")
  val path = opt[String](default = Some("/tmp/lda/"), descr = "model path")
  val json = opt[String](default = Some("/both.json"), descr = "training file resource path")
  verify()
}
