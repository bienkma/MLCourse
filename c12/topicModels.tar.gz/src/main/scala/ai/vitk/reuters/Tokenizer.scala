package ai.vitk.reuters

import org.apache.spark.ml.UnaryTransformer
import org.apache.spark.ml.util.{DefaultParamsReadable, DefaultParamsWritable, Identifiable}
import org.apache.spark.sql.types.{ArrayType, StringType}

/**
  * phuonglh, 10/3/17, 10:40
  * 
  * Customized tokenizer for the Reuters corpus.
  */
class Tokenizer(override val uid: String) extends UnaryTransformer[String, Seq[String], Tokenizer] with DefaultParamsWritable {
  
  val ignores = List(".", "!", "?", ",", "--", "-")
  
  def this() = this(Identifiable.randomUID("tokenizer"))
  
  override protected def createTransformFunc: (String) => Seq[String] = {
    def f(text: String): List[String] = {
      text.replaceAll("\\<.*?\\>", "")
        .replaceAll("\\[.*?\\]", "")
        .replaceAll("[)(]+", "")
        .replaceAll("'s", "")
        .replaceAll("[,.]\\s", " , ")
        .split("\\s+")
        .map(token => WordShape.shape(token) match {
          case "date" => "<DATE>"
          case "number" => "<NUMBER>"
          case _ => token
        }).filterNot(ignores.contains(_)).toList
    }
    
    f(_)
  }

  override protected def outputDataType = new ArrayType(StringType, false)
}

object Tokenizer extends DefaultParamsReadable[Tokenizer] {
  override def load(path: String): Tokenizer = super.load(path)
}
